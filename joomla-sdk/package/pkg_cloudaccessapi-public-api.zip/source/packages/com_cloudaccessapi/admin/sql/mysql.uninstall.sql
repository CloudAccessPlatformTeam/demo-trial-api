DROP TABLE IF EXISTS `#__demoapi_activation_codes`;
DROP TABLE IF EXISTS `#__demoapi_authentication`;