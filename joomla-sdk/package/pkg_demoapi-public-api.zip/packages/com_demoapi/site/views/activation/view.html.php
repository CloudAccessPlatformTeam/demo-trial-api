<?php
/**
* @package Cloud Panel Component for Joomla!
* @author CloudAccess.net LCC
* @copyright (C) 2010 - CloudAccess.net LCC
* @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

//!no direct access
defined ('_JEXEC') or die ('Restricted access');

/**
* Cloud Panel view.
*
* @package Joomla.Administrator
* @subpackage com_cloudpanel
* @since 3.0
*/
class DemoApiViewActivation extends DRView
{
    
}