DROP TABLE IF EXISTS `#__demoregister_activation_codes`;
DROP TABLE IF EXISTS `#__demoregister_authentication`;